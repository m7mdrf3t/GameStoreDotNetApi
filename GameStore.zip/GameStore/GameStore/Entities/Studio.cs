namespace GameStore.Entities;

public class Studio
{
    public int id { get; set; }

    public string name { get; set; }
}
