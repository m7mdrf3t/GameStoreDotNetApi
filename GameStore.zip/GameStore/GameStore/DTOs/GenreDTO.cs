namespace GameStore.DTOs;

public record GenreDTO(int id , string name);